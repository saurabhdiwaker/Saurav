
package moto;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "search", urlPatterns = {"/search"})
public class search extends HttpServlet {
public static String data[][]= new String[5][5] ;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String s1=request.getParameter("s1");
        String s2=request.getParameter("s2");
         try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
            Statement smt=con.createStatement();
            ResultSet rs=smt.executeQuery("select*from JOBPORTAL where expe='"+s1+"' AND type='"+s2+"'");
            int i=0;
            while(rs.next())
                for(int j=0;j<5;j++)
                {
                    data[i][j]=rs.getString(j+1);
                }
            response.sendRedirect("Home.jsp");
            }    
         catch (ClassNotFoundException | SQLException ex) {
            response.getWriter().print(ex.toString());
        }
    }
}
